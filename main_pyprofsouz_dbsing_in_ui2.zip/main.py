import sys
import sqlite3

from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QDialog, QPushButton, QLabel


class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('sing_in.ui', self)

        self.sing_in.clicked.connect(self.sing_in_func)
        self.sing_up.clicked.connect(self.sing_up_func)

    def sing_up_func(self):
        self.suo = Sing_up_one_wind()
        self.suo.show()
        ex.close()

    def sing_in_func(self):
        self.email_sing_in = self.email_edit.text()
        self.password_sing_in = self.password_edit.text()
        con = sqlite3.connect('profsouz.db')
        cur = con.cursor()
        usl = f'SELECT email, password FROM people WHERE email == "{self.email_sing_in}" AND password == "{self.password_sing_in}"'
        res = cur.execute(usl).fetchall()
        print(res)
        if res:
            pass
        else:
            def ok_pressed():
                self.email_edit.setText('')
                self.password_edit.setText('')
                dialog.close()

            dialog = QDialog()
            dialog.setGeometry(200, 100, 525, 100)
            ok_btn = QPushButton(dialog)
            stat_lab = QLabel(dialog)
            stat_lab.setText('Пользователь с такими данными не найден или введенные данные неверны')
            stat_lab.move(20, 20)
            ok_btn.setText('OK')
            ok_btn.setGeometry(210, 50, 70, 25)
            ok_btn.setStyleSheet('QPushButton {background: rgb(254, 127, 94); color: "white"; '
                                 'border: 2px solid rgb(254, 127, 94); border-radius: 10px} '
                                 'QPushButton:pressed {background: rgb(234, 107, 74)}')
            ok_btn.clicked.connect(ok_pressed)
            dialog.exec_()
        con.close()


class Sing_up_one_wind(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi('sing_up_one.ui', self)

        self.next_button.clicked.connect(self.next_func)

    def next_func(self):
        ex.suo.close()
        self.sud = Sing_up_two_wind()
        self.sud.show()


class Sing_up_two_wind(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi('sing_up_two.ui', self)

        self.sing_up_button.clicked.connect(self.sing_up_func)

    def sing_up_func(self):
        fio = f'{ex.suo.fam_edit.text()} {ex.suo.name_edit.text()} {ex.suo.father_edit.text()}'
        con = sqlite3.connect('profsouz.db')
        cur = con.cursor()
        usl = f'INSERT INTO people(email, fio, password, number, autent) VALUES("{self.email_edit.text()}", "{fio}", ' \
              f'"{self.password_edit.text()}", "{self.number_edit.text()}", "False")'
        res = cur.execute(usl)
        con.commit()
        con.close()
        ex.suo.sud.close()
        ex.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec_())
